# Phase 4-6: SEO 설정, 콘텐츠 확장, 수익화 준비

> 목표: 검색 엔진 등록, 콘텐츠 30개 달성, 수익화 시스템 구축
> 예상 소요 시간: 1-2주

---

## Phase 4: SEO 기본 설정

### 작업 개요

1. Google Search Console 등록
2. Naver Search Advisor 등록
3. Google Analytics 4 설정
4. Sitemap 제출
5. 구조화된 데이터 검증

---

## Step 1: Google Search Console 등록

### 웹 인터페이스 작업

```
1. https://search.google.com/search-console 접속
2. Google 계정으로 로그인
3. "속성 추가" 클릭
```

### 속성 유형 선택

```
"URL 접두어" 선택
URL 입력: https://adpress.kr
"계속" 클릭
```

### 소유권 확인

**방법 1: HTML 태그 (권장)**

```
1. "HTML 태그" 방법 선택
2. 메타 태그 복사:
   <meta name="google-site-verification" content="XXXXXXXXXXXX" />

3. 프로젝트에서 app/layout.tsx 수정:
```

```tsx
// app/layout.tsx
export default function RootLayout({ children }) {
  return (
    <html lang="ko">
      <head>
        <meta name="google-site-verification" content="XXXXXXXXXXXX" />
      </head>
      <body>{children}</body>
    </html>
  );
}
```

```bash
# Git 커밋 및 푸시
git add app/layout.tsx
git commit -m "feat: Google Search Console 소유권 확인 태그 추가"
git push origin main

# 배포 대기 (2-3분)
```

```
4. Search Console로 돌아와서 "확인" 클릭
```

**방법 2: DNS 레코드**

```
1. "도메인 이름 공급업체" 선택 > Cloudflare
2. TXT 레코드 복사
3. Cloudflare DNS 관리에서 추가:
   Type: TXT
   Name: @
   Content: google-site-verification=XXXXXXXXXXXX
4. Search Console로 돌아와서 "확인" 클릭
```

### Sitemap 제출

```
1. Search Console > Sitemaps
2. 새 사이트맵 추가:
   https://adpress.kr/sitemap.xml
3. "제출" 클릭
```

### 예상 결과

```
✓ 소유권 확인 완료
✓ Sitemap 제출 완료
⏳ 색인 생성 중... (1-7일 소요)
```

---

## Step 2: Naver Search Advisor 등록

### 웹 인터페이스 작업

```
1. https://searchadvisor.naver.com/ 접속
2. 네이버 계정으로 로그인
3. "웹마스터 도구" 클릭
4. "사이트 등록" 클릭
```

### 사이트 정보 입력

```
사이트 URL: https://adpress.kr
사이트 이름: AdPress (애드프레스)
"등록" 클릭
```

### 소유권 확인

**HTML 파일 업로드 방법:**

```
1. "HTML 파일 업로드" 선택
2. 파일 다운로드: naverXXXXXXXXXXXX.html

3. 프로젝트에서 public/ 폴더에 복사:
```

```bash
# 다운로드한 파일을 public/ 폴더로 이동
cp ~/Downloads/naverXXXXXXXXXXXX.html public/

# Git 커밋 및 푸시
git add public/naverXXXXXXXXXXXX.html
git commit -m "feat: Naver Search Advisor 소유권 확인 파일 추가"
git push origin main

# 배포 대기 (2-3분)
```

```
4. Search Advisor로 돌아와서
5. https://adpress.kr/naverXXXXXXXXXXXX.html 접속 확인
6. "소유확인" 클릭
```

### Sitemap 제출

```
1. 웹마스터 도구 > 요청 > 사이트맵 제출
2. URL 입력: https://adpress.kr/sitemap.xml
3. "확인" 클릭
```

### RSS 제출 (선택사항)

```
1. 요청 > RSS 제출
2. URL 입력: https://adpress.kr/rss.xml (구현된 경우)
3. "확인" 클릭
```

---

## Step 3: Google Analytics 4 설정

### GA4 계정 생성

```
1. https://analytics.google.com/ 접속
2. "측정 시작" 클릭
3. 계정 이름: AdPress
4. "다음" 클릭
```

### 속성 생성

```
속성 이름: AdPress (adpress.kr)
시간대: (GMT+09:00) 한국 시간
통화: 대한민국 원 (₩)
"다음" 클릭
```

### 비즈니스 정보

```
업종: 미디어 및 게시
비즈니스 규모: 소규모
사용 목적: 콘텐츠 게시자로서 측정
"만들기" 클릭
```

### 데이터 스트림 설정

```
플랫폼: 웹
웹사이트 URL: https://adpress.kr
스트림 이름: AdPress Web
"스트림 만들기" 클릭
```

### 측정 ID 복사

```
측정 ID: G-XXXXXXXXXX
(이 ID를 복사해둠)
```

### 프로젝트에 GA4 적용

```bash
# .env.local 파일 수정
nano .env.local
```

```bash
# .env.local 에 추가
NEXT_PUBLIC_GA_ID=G-XXXXXXXXXX
```

```bash
# Cloudflare Pages 환경 변수에도 추가
# Cloudflare Dashboard > Pages > adpress-kr > Settings > Environment variables
# Variable name: NEXT_PUBLIC_GA_ID
# Value: G-XXXXXXXXXX
# "Save" 클릭
```

```bash
# 재배포 트리거 (환경 변수 변경 시 필요)
# Cloudflare Pages > Deployments > "Retry deployment"
# 또는 Git 푸시로 자동 배포
git commit --allow-empty -m "chore: GA4 환경 변수 업데이트"
git push origin main
```

### GA4 작동 확인

```
1. https://adpress.kr 접속
2. GA4 대시보드 > 보고서 > 실시간
3. 1-2분 내 실시간 사용자 1명 표시 확인
```

---

## Step 4: 구조화된 데이터 검증

### Google Rich Results Test

```
1. https://search.google.com/test/rich-results 접속
2. URL 입력: https://adpress.kr/guides/adsense-approval-method-2024
3. "URL 테스트" 클릭
```

### 예상 결과

```
✓ Article 스키마 감지됨
  - headline
  - datePublished
  - author
  - publisher
  - image
```

### 에러 수정 (필요시)

만약 에러가 있다면:

```tsx
// app/guides/[slug]/page.tsx
// JSON-LD 스키마 확인 및 수정

const articleSchema = {
  '@context': 'https://schema.org',
  '@type': 'Article',
  headline: post.title,
  description: post.description,
  image: post.thumbnail || 'https://adpress.kr/images/og-default.png',
  datePublished: post.date,
  dateModified: post.updated || post.date,
  author: {
    '@type': 'Organization',
    name: 'AdPress'
  },
  publisher: {
    '@type': 'Organization',
    name: 'AdPress',
    logo: {
      '@type': 'ImageObject',
      url: 'https://adpress.kr/images/logo.png'
    }
  }
};
```

---

## ✅ Phase 4 완료 체크리스트

- [ ] Google Search Console 소유권 확인
- [ ] Google Search Console Sitemap 제출
- [ ] Naver Search Advisor 소유권 확인
- [ ] Naver Search Advisor Sitemap 제출
- [ ] Google Analytics 4 설정
- [ ] GA4 측정 ID 환경 변수 추가
- [ ] GA4 실시간 데이터 확인
- [ ] Rich Results Test 통과

---

## Phase 5: 콘텐츠 확장 (20→30개)

### 작업 개요

1. 키워드 우선순위 재확인
2. 일괄 콘텐츠 생성 (20개)
3. 품질 검토 및 수정
4. 내부 링크 네트워크 구축
5. 이미지 추가

---

## Step 1: 추가 콘텐츠 20개 생성

### 키워드 선택

keywords.txt에서 high/medium 우선순위 20개 선택:

```bash
# scripts/generate-batch.sh 생성
cat > scripts/generate-batch.sh << 'EOF'
#!/bin/bash

keywords=(
  "광고 배치 최적화 전략|guides|medium"
  "애드센스 RPM 올리는 법|guides|medium"
  "고수익 CPC 키워드 찾기|guides|medium"
  "모바일 광고 최적화 가이드|guides|medium"
  "애드센스 CPC 높이는 방법|tips|medium"
  "애드센스 정책 위반 피하기|tips|medium"
  "애드센스 광고 클릭률 높이기|tips|medium"
  "애드센스 수익 정산 방법|tips|medium"
  "애드포스트 CPC 높이기|tips|medium"
  "애드포스트 최적 배치|tips|medium"
  "네이버 블로그 애드포스트 설정|tips|medium"
  "광고 클릭률 높이는 배치|tips|high"
  "모바일 광고 배치 전략|tips|medium"
  "블로그 트래픽 늘리는 법|tips|medium"
  "SEO 키워드 리서치 방법|tips|medium"
  "티스토리 vs 워드프레스 수익 비교|reviews|high"
  "애드센스 대안 광고 플랫폼|reviews|medium"
  "블로그 호스팅 추천|reviews|medium"
  "SEO 키워드 도구 비교|reviews|medium"
  "애드센스 월 100만원 달성 후기|guides|medium"
)

echo "🚀 20개 콘텐츠 일괄 생성 시작..."

count=0
for item in "${keywords[@]}"; do
  IFS='|' read -r keyword category priority <<< "$item"
  count=$((count + 1))
  echo ""
  echo "[$count/20] 생성 중: $keyword"
  python generate_content.py --keyword "$keyword" --category "$category"
  sleep 3  # API Rate Limit 방지
done

echo ""
echo "✅ 20개 콘텐츠 생성 완료!"
echo "📊 총 콘텐츠 개수: $(find ../content -name '*.mdx' | wc -l)개"
EOF

chmod +x scripts/generate-batch.sh
```

### 일괄 생성 실행

```bash
cd scripts
./generate-batch.sh
cd ..
```

### 예상 소요 시간

- 콘텐츠당 약 1분 (API 호출 + 대기)
- 총 20개: 약 20-25분

---

## Step 2: 생성된 콘텐츠 품질 검토

### 자동 검증 스크립트

```python
# scripts/validate_content.py
import os
import frontmatter

def validate_mdx_files(directory):
    """MDX 파일들의 기본 품질 검증"""
    errors = []
    
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.mdx'):
                filepath = os.path.join(root, file)
                
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        post = frontmatter.load(f)
                    
                    # Frontmatter 검증
                    required_fields = ['title', 'description', 'date', 'category']
                    for field in required_fields:
                        if field not in post.metadata:
                            errors.append(f"{filepath}: Missing {field}")
                    
                    # 본문 길이 검증
                    content_length = len(post.content)
                    if content_length < 1000:
                        errors.append(f"{filepath}: Too short ({content_length} chars)")
                    
                    # 제목 길이
                    if len(post.metadata.get('title', '')) > 60:
                        errors.append(f"{filepath}: Title too long")
                    
                    # 설명 길이
                    desc = post.metadata.get('description', '')
                    if len(desc) > 160:
                        errors.append(f"{filepath}: Description too long ({len(desc)})")
                    
                except Exception as e:
                    errors.append(f"{filepath}: Parse error - {e}")
    
    return errors

if __name__ == '__main__':
    errors = validate_mdx_files('../content')
    
    if errors:
        print("⚠️  발견된 문제:")
        for error in errors:
            print(f"  - {error}")
    else:
        print("✅ 모든 콘텐츠 검증 통과!")
```

```bash
# 실행
python scripts/validate_content.py
```

### 수동 샘플 체크

```bash
# 랜덤으로 5개 샘플 확인
find content -name "*.mdx" | shuf -n 5 | while read file; do
  echo "=== $file ==="
  head -n 30 "$file"
  echo ""
done
```

---

## Step 3: 내부 링크 네트워크 구축

### 관련 글 자동 연결 스크립트

```python
# scripts/add_internal_links.py
import os
import frontmatter
import random

def add_related_posts_to_mdx(filepath, related_posts):
    """MDX 파일에 관련 글 섹션 추가"""
    
    with open(filepath, 'r', encoding='utf-8') as f:
        post = frontmatter.load(f)
    
    content = post.content
    
    # 이미 관련 글 섹션이 있으면 스킵
    if '## 관련 가이드' in content or '## 다음 단계' in content:
        return
    
    # 관련 글 섹션 추가
    related_section = "\n\n---\n\n## 다음 단계\n\n"
    
    for related in related_posts[:3]:  # 최대 3개
        related_section += f"- [{related['title']}]({related['url']})\n"
    
    # 본문 끝에 추가
    updated_content = content + related_section
    
    # 파일 업데이트
    post.content = updated_content
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(frontmatter.dumps(post))

# 실행 로직 생략 (전체 구현은 프로젝트에서)
```

---

## Step 4: Git 커밋

```bash
# 생성된 모든 콘텐츠 추가
git add content/

# 커밋
git commit -m "content: 20개 추가 콘텐츠 생성

- Guides: 10개
- Tips: 8개
- Reviews: 2개

총 콘텐츠: 26개"

# 푸시
git push origin main
```

---

## ✅ Phase 5 완료 체크리스트

- [ ] 추가 콘텐츠 20개 생성
- [ ] 품질 검증 스크립트 실행
- [ ] 샘플 콘텐츠 수동 확인
- [ ] 내부 링크 추가
- [ ] Git 커밋 및 푸시
- [ ] 사이트 배포 확인
- [ ] 총 콘텐츠 26개 이상

---

## Phase 6: 수익화 준비

### 작업 개요

1. Privacy Policy 페이지 작성
2. Contact 페이지 작성
3. Google AdSense 신청
4. 쿠팡 파트너스 가입
5. Mailchimp 설정

---

## Step 1: Privacy Policy 페이지

### 파일 생성

```tsx
// app/privacy/page.tsx
export default function PrivacyPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">개인정보 처리방침</h1>
      
      <section className="prose prose-lg">
        <h2>1. 개인정보의 처리 목적</h2>
        <p>
          AdPress(이하 "사이트")는 다음의 목적을 위하여 개인정보를 처리합니다.
          처리하고 있는 개인정보는 다음의 목적 이외의 용도로는 이용되지 않으며,
          이용 목적이 변경되는 경우에는 별도의 동의를 받는 등 필요한 조치를 이행할 예정입니다.
        </p>
        
        <h2>2. 처리하는 개인정보 항목</h2>
        <ul>
          <li>뉴스레터 구독: 이메일 주소</li>
          <li>Google Analytics: IP 주소, 쿠키 정보, 방문 기록</li>
        </ul>
        
        {/* 나머지 내용... */}
      </section>
    </div>
  );
}
```

### Git 커밋

```bash
git add app/privacy/
git commit -m "feat: Privacy Policy 페이지 추가"
git push origin main
```

---

## Step 2: Google AdSense 신청

### 신청 전 체크리스트

```
✓ 콘텐츠 30개 이상
✓ Privacy Policy 페이지
✓ Contact 페이지
✓ 도메인 소유권 확인
✓ 6개월 이내 도메인 (adpress.kr)
✓ 저작권 위반 콘텐츠 없음
✓ 정책 준수 (성인 콘텐츠, 폭력 등 없음)
```

### 신청 절차

```
1. https://www.google.com/adsense/ 접속
2. "시작하기" 클릭
3. 웹사이트 URL: https://adpress.kr
4. 이메일 주소 입력
5. AdSense 정책 동의
6. "AdSense로 이동" 클릭
7. 사이트 연결 (코드 삽입)
```

### 코드 삽입

```tsx
// app/layout.tsx
export default function RootLayout({ children }) {
  return (
    <html lang="ko">
      <head>
        {/* AdSense 코드 */}
        <script
          async
          src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX"
          crossOrigin="anonymous"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
```

### 승인 대기

```
예상 기간: 1-2주
상태 확인: AdSense 대시보드
```

---

## Step 3: 쿠팡 파트너스 가입

### 가입 절차

```
1. https://partners.coupang.com/ 접속
2. "파트너 가입하기" 클릭
3. 정보 입력:
   - 이름
   - 이메일
   - 전화번호
   - 사이트 URL: https://adpress.kr
4. 약관 동의
5. "가입하기" 클릭
```

### 승인 대기

```
예상 기간: 1-3일
승인 기준: 콘텐츠 품질, 트래픽
```

### 링크 생성 (승인 후)

```
1. 파트너스 대시보드 > 링크 생성
2. 상품 검색: "블로그 노트북"
3. 링크 복사
4. data/affiliate-links.json에 추가
```

---

## Step 4: Mailchimp 설정

### 계정 생성

```
1. https://mailchimp.com/ 접속
2. "Sign Up Free" 클릭
3. 이메일, 사용자명, 비밀번호 입력
4. 이메일 인증
```

### Audience (리스트) 생성

```
1. Audience > All contacts
2. "Create Audience" 클릭
3. Audience name: AdPress Subscribers
4. Default from email: your-email@example.com
5. "Save" 클릭
```

### API Key 발급

```
1. Account > Extras > API keys
2. "Create A Key" 클릭
3. API key 복사 (xxxxx-us1 형식)
```

### List ID 확인

```
1. Audience > All contacts
2. Settings > Audience name and defaults
3. Audience ID 복사
```

### 환경 변수 추가

```bash
# .env.local
MAILCHIMP_API_KEY=xxxxx-us1
MAILCHIMP_LIST_ID=xxxxxx

# Cloudflare Pages 환경 변수에도 추가
```

---

## ✅ Phase 6 완료 체크리스트

- [ ] Privacy Policy 페이지 작성
- [ ] Contact 페이지 작성
- [ ] AdSense 신청 완료
- [ ] 쿠팡 파트너스 가입 신청
- [ ] Mailchimp 계정 생성
- [ ] Mailchimp API 연동
- [ ] 뉴스레터 구독 폼 테스트

---

## 🎯 전체 Phase 완료

Phase 1-6 모두 완료 시:

### 달성한 것들

```
✅ 로컬 개발 환경 구축
✅ AI 콘텐츠 자동 생성 시스템
✅ GitHub + Cloudflare Pages 배포
✅ 도메인 연결 (adpress.kr)
✅ Google/Naver 검색 등록
✅ Google Analytics 4 설정
✅ 콘텐츠 30개 발행
✅ 수익화 시스템 준비 (AdSense, 쿠팡)
✅ 이메일 수집 시스템 (Mailchimp)
```

### 다음 단계

**Week 3-4:**
- 콘텐츠 50개 달성
- AdSense 승인 대기
- 네이버 블로그/카페 마케팅
- 검색 노출 모니터링

**Month 2:**
- 일 방문자 100-300 UV 목표
- AdSense 승인 후 광고 배치 최적화
- A/B 테스트
- 월간 수익 리포트 발행

**Month 3:**
- 유료 강의 런칭 준비
- 멤버십 프로그램 설계
- 월 수익 100만원 목표

---

## 📞 지원 및 리소스

### 공식 문서

- Next.js: https://nextjs.org/docs
- Cloudflare Pages: https://developers.cloudflare.com/pages/
- Google Search Console: https://support.google.com/webmasters/
- AdSense: https://support.google.com/adsense/

### 커뮤니티

- Next.js Discord
- Cloudflare Discord
- Google Webmaster Community

---

*Last Updated: 2024-04-14*
*Phase: 4-6/6*
