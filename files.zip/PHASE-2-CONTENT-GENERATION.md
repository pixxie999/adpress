# Phase 2: 첫 콘텐츠 생성 및 테스트

> 목표: AI를 활용한 첫 번째 콘텐츠 생성 및 사이트 확인
> 예상 소요 시간: 1시간

---

## 작업 개요

1. keywords.txt 파일 복사
2. AI 콘텐츠 생성 스크립트 테스트 (수동 1개)
3. 생성된 콘텐츠 품질 확인
4. 사이트에서 콘텐츠 렌더링 확인
5. 일괄 생성 테스트 (5개)

---

## Step 1: Keywords 파일 준비

### 실행할 명령어

```bash
# 프로젝트 루트에서 실행
# keywords.txt 파일을 scripts/ 폴더로 복사
cp keywords.txt scripts/keywords.txt

# 복사 확인
ls -la scripts/keywords.txt

# 파일 내용 미리보기 (처음 10줄)
head -n 20 scripts/keywords.txt
```

### 예상 결과

`scripts/keywords.txt` 파일이 생성되고 다음과 같은 내용이 보여야 함:

```
# AdPress.kr 키워드 리스트
# Format: 키워드|카테고리|우선순위|예상 검색량

애드센스 승인 받는 방법 2024|guides|high|5000
애드센스 승인 조건 완벽 정리|guides|high|3000
...
```

---

## Step 2: 첫 번째 콘텐츠 생성 (단일 테스트)

### 실행 전 확인사항

1. `.env.local`에 `ANTHROPIC_API_KEY`가 설정되어 있는지 확인
2. Python 가상환경이 활성화되어 있는지 확인

```bash
# 환경 변수 확인
echo $ANTHROPIC_API_KEY

# Python 가상환경 활성화 (아직 안 했다면)
source venv/bin/activate  # Mac/Linux
# venv\Scripts\activate   # Windows
```

### 단일 콘텐츠 생성 명령어

```bash
# scripts 폴더로 이동
cd scripts

# 첫 번째 가이드 생성 (테스트)
python generate_content.py \
  --keyword "애드센스 승인 받는 방법 2024" \
  --category guides

# 프로젝트 루트로 복귀
cd ..
```

### 예상 실행 과정

터미널에 다음과 같은 메시지가 표시되어야 함:

```
🤖 AdPress 콘텐츠 생성 시작...
📝 키워드: 애드센스 승인 받는 방법 2024
📁 카테고리: guides
🔄 Claude API 호출 중...
✅ 콘텐츠 생성 완료!
📄 저장 위치: content/guides/adsense-approval-method-2024.mdx
⏱️ 예상 읽기 시간: 8분
```

### 생성 시간

- Claude API 호출: 10-30초
- 총 소요 시간: 약 1분 이내

---

## Step 3: 생성된 콘텐츠 확인

### 파일 확인

```bash
# 생성된 MDX 파일 확인
ls -la content/guides/

# 파일 내용 확인
cat content/guides/adsense-approval-method-2024.mdx
```

### 품질 체크리스트

생성된 MDX 파일이 다음 요소들을 포함하는지 확인:

#### 1. Frontmatter 구조

```yaml
---
title: "..."
description: "..."
date: "2024-04-14"
category: "guides"
tags: [...]
thumbnail: "/images/guides/placeholder.jpg"
readingTime: 8
seo:
  keywords: [...]
---
```

#### 2. 본문 구조

- [ ] H2, H3 헤딩이 적절히 사용되었는가?
- [ ] 도입부가 명확한가? (문제 제시, 공감)
- [ ] 본론에 단계별 실행 방법이 있는가?
- [ ] 구체적인 예시나 팁이 포함되어 있는가?
- [ ] 결론에 다음 단계 안내가 있는가?

#### 3. 내용 품질

- [ ] 한글이 자연스러운가?
- [ ] 과장된 표현이 없는가?
- [ ] 실용적인 정보인가?
- [ ] 분량이 적절한가? (1,500-3,000자)

#### 4. SEO 최적화

- [ ] 메타 디스크립션이 150자 이내인가?
- [ ] 타겟 키워드가 자연스럽게 포함되었는가?
- [ ] 내부 링크 추천이 있는가?

### 수동 수정 (필요시)

품질이 부족하면 다음과 같이 재생성:

```bash
# 다른 프롬프트로 재시도
python scripts/generate_content.py \
  --keyword "애드센스 승인 받는 방법 2024" \
  --category guides \
  --regenerate
```

또는 MDX 파일을 직접 편집:

```bash
# VSCode로 열기
code content/guides/adsense-approval-method-2024.mdx

# 또는 nano 에디터
nano content/guides/adsense-approval-method-2024.mdx
```

---

## Step 4: 사이트에서 렌더링 확인

### 개발 서버 실행

```bash
# 새 터미널 창에서 (또는 기존 터미널 사용)
npm run dev
```

### 브라우저 확인

1. 브라우저에서 가이드 목록 페이지 접속:
   ```
   http://localhost:3000/guides
   ```

2. 방금 생성한 글이 목록에 보이는지 확인

3. 글 클릭하여 상세 페이지 확인:
   ```
   http://localhost:3000/guides/adsense-approval-method-2024
   ```

### 렌더링 체크리스트

- [ ] 제목이 정상적으로 표시되는가?
- [ ] 메타 정보(날짜, 카테고리, 읽기 시간)가 보이는가?
- [ ] 본문이 적절히 포맷팅되어 있는가?
- [ ] H2, H3 헤딩 스타일이 적용되었는가?
- [ ] 이미지 placeholder가 깨지지 않았는가?
- [ ] 목차(TOC)가 자동 생성되었는가?
- [ ] 관련 글 추천이 있는가?

### 문제 해결

**콘텐츠가 목록에 안 보이는 경우:**

```bash
# 캐시 삭제
rm -rf .next

# 개발 서버 재시작
npm run dev
```

**MDX 파싱 에러:**

```bash
# MDX 문법 검증
npx eslint content/guides/adsense-approval-method-2024.mdx

# Frontmatter 유효성 검사
python scripts/validate_mdx.py content/guides/adsense-approval-method-2024.mdx
```

---

## Step 5: 추가 콘텐츠 일괄 생성 (5개)

### 고우선순위 키워드 5개 선택

keywords.txt에서 다음 5개를 선택하여 생성:

```bash
cd scripts

# 2번째 가이드
python generate_content.py \
  --keyword "애드센스 승인 조건 완벽 정리" \
  --category guides

# 3번째 가이드
python generate_content.py \
  --keyword "애드포스트 시작 가이드" \
  --category guides

# 4번째 가이드
python generate_content.py \
  --keyword "애드센스 vs 애드포스트 비교" \
  --category guides

# 5번째 가이드
python generate_content.py \
  --keyword "블로그 광고 수익화 로드맵" \
  --category guides

# 첫 번째 팁
python generate_content.py \
  --keyword "애드센스 승인 거절 사유" \
  --category tips

cd ..
```

### 일괄 생성 스크립트 (선택사항)

또는 다음 스크립트를 사용하여 자동화:

```bash
# scripts/batch-generate.sh 파일 생성
cat > scripts/batch-generate.sh << 'EOF'
#!/bin/bash

echo "🚀 AdPress 초기 콘텐츠 5개 생성 시작..."

keywords=(
  "애드센스 승인 조건 완벽 정리|guides"
  "애드포스트 시작 가이드|guides"
  "애드센스 vs 애드포스트 비교|guides"
  "블로그 광고 수익화 로드맵|guides"
  "애드센스 승인 거절 사유|tips"
)

for item in "${keywords[@]}"; do
  IFS='|' read -r keyword category <<< "$item"
  echo ""
  echo "📝 생성 중: $keyword"
  python generate_content.py --keyword "$keyword" --category "$category"
  sleep 5  # API Rate Limit 방지
done

echo ""
echo "✅ 5개 콘텐츠 생성 완료!"
EOF

# 실행 권한 부여
chmod +x scripts/batch-generate.sh

# 실행
./scripts/batch-generate.sh
```

### 예상 소요 시간

- 콘텐츠 1개당 약 1분
- 총 5개: 약 5-7분 (API 대기 시간 포함)

---

## Step 6: 생성된 콘텐츠 일괄 확인

### 파일 목록 확인

```bash
# guides 폴더 확인
ls -la content/guides/

# tips 폴더 확인
ls -la content/tips/

# 총 콘텐츠 개수
find content -name "*.mdx" | wc -l
```

### 예상 결과

```
content/guides/
  - adsense-approval-method-2024.mdx
  - adsense-approval-conditions-2024.mdx
  - adpost-start-guide.mdx
  - adsense-vs-adpost-comparison.mdx
  - blog-ad-monetization-roadmap.mdx

content/tips/
  - adsense-rejection-reasons.mdx

총 6개 MDX 파일
```

### 브라우저에서 전체 확인

```bash
# 개발 서버가 실행 중인지 확인
# http://localhost:3000/guides 접속

# 각 글 클릭하여 렌더링 확인
```

---

## Step 7: Git 커밋

### 생성된 콘텐츠를 Git에 추가

```bash
# 생성된 파일 상태 확인
git status

# 콘텐츠 파일 추가
git add content/

# 커밋
git commit -m "✨ Add initial 6 content pieces

- 애드센스 승인 받는 방법 2024
- 애드센스 승인 조건 완벽 정리
- 애드포스트 시작 가이드
- 애드센스 vs 애드포스트 비교
- 블로그 광고 수익화 로드맵
- 애드센스 승인 거절 사유 (팁)"

# 로컬 저장소 상태 확인
git log --oneline -n 3
```

---

## ✅ Phase 2 완료 체크리스트

다음 항목들이 모두 체크되면 Phase 2 완료:

- [ ] keywords.txt 파일을 scripts/ 폴더에 복사
- [ ] 첫 번째 콘텐츠 성공적으로 생성
- [ ] 생성된 MDX 파일의 구조 및 품질 확인
- [ ] 브라우저에서 렌더링 정상 확인
- [ ] 추가 5개 콘텐츠 일괄 생성 완료
- [ ] 총 6개 콘텐츠 파일 존재
- [ ] 모든 콘텐츠가 사이트에서 정상 표시
- [ ] Git 커밋 완료

---

## 📊 생성된 콘텐츠 통계

### 카테고리별 분포

```bash
# 통계 스크립트 실행
cat > scripts/content-stats.sh << 'EOF'
#!/bin/bash

echo "📊 AdPress 콘텐츠 통계"
echo "======================="
echo "Guides: $(ls content/guides/*.mdx 2>/dev/null | wc -l)개"
echo "Tips: $(ls content/tips/*.mdx 2>/dev/null | wc -l)개"
echo "Reviews: $(ls content/reviews/*.mdx 2>/dev/null | wc -l)개"
echo "Income Reports: $(ls content/income-reports/*.mdx 2>/dev/null | wc -l)개"
echo "======================="
echo "총 콘텐츠: $(find content -name "*.mdx" | wc -l)개"
EOF

chmod +x scripts/content-stats.sh
./scripts/content-stats.sh
```

### 예상 출력

```
📊 AdPress 콘텐츠 통계
=======================
Guides: 5개
Tips: 1개
Reviews: 0개
Income Reports: 0개
=======================
총 콘텐츠: 6개
```

---

## 🐛 문제 해결 가이드

### 문제 1: Claude API 에러

**증상:**
```
Error: API key not found
```

**해결:**
```bash
# .env.local 확인
cat .env.local | grep ANTHROPIC

# API 키 재설정
nano .env.local

# Python 스크립트 재실행
python scripts/generate_content.py --keyword "..." --category guides
```

### 문제 2: MDX 파싱 에러

**증상:**
브라우저에서 "Failed to compile" 에러

**해결:**
```bash
# MDX 파일 문법 확인
# Frontmatter가 올바른 YAML 형식인지 확인
# --- 로 시작하고 끝나는지 확인

# 문제가 있는 파일 재생성
python scripts/generate_content.py \
  --keyword "..." \
  --category guides \
  --force
```

### 문제 3: 한글 인코딩 깨짐

**증상:**
한글이 깨져서 표시됨

**해결:**
```python
# generate_content.py 파일 수정
# 파일 저장 시 encoding='utf-8' 확인

with open(filename, 'w', encoding='utf-8') as f:
    f.write(content)
```

### 문제 4: API Rate Limit

**증상:**
```
Error: Rate limit exceeded
```

**해결:**
```bash
# 일괄 생성 시 딜레이 추가
# batch-generate.sh 스크립트에서
sleep 5  # 각 생성 사이 5초 대기
```

---

## 🎯 다음 단계 미리보기

Phase 2 완료 후:

➡️ **PHASE-3-GITHUB-DEPLOYMENT.md**

- GitHub 저장소 생성
- 코드 푸시
- Cloudflare Pages 연결
- 도메인 연결 (adpress.kr)

---

## 💡 추가 팁

### 콘텐츠 품질 향상

1. **첫 3-5개는 수동 검토 필수**
   - AI 생성 후 직접 읽어보고 수정
   - 실제 경험 기반 내용 추가
   - 구체적인 예시/수치 보강

2. **프롬프트 개선**
   - `generate_content.py`의 프롬프트를 커스터마이징
   - 특정 톤앤매너 강조
   - 더 구체적인 요구사항 추가

3. **이미지 준비**
   - 각 가이드용 썸네일 이미지 준비
   - `/public/images/guides/` 폴더에 저장
   - Frontmatter에서 thumbnail 경로 업데이트

---

*Last Updated: 2024-04-14*
*Phase: 2/6*
