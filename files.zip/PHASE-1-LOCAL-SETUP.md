# Phase 1: 로컬 환경 세팅 및 테스트

> 목표: 프로젝트를 로컬에서 실행하고 정상 작동 확인
> 예상 소요 시간: 30분

---

## 작업 개요

1. Node.js 의존성 설치
2. 환경 변수 설정
3. 개발 서버 실행 및 확인
4. Python 환경 설정
5. 프로젝트 구조 검증

---

## Step 1: Node.js 의존성 설치

### 실행할 명령어

```bash
# 프로젝트 루트 디렉토리로 이동
cd adpress

# package.json 기반 의존성 설치
npm install

# 설치 완료 확인
npm list --depth=0
```

### 예상 결과
- `node_modules/` 폴더 생성됨
- 다음 주요 패키지들이 설치되어야 함:
  - next@^14.2.0
  - react@^18.3.0
  - tailwindcss@^3.4.0
  - typescript@^5.3.0

### 문제 해결
- 에러 발생 시: `rm -rf node_modules package-lock.json && npm install`
- Node.js 버전 확인: `node --version` (v18 이상 필요)

---

## Step 2: 환경 변수 설정

### 실행할 명령어

```bash
# .env.local.example을 복사하여 .env.local 생성
cp .env.local.example .env.local
```

### .env.local 파일 편집

다음 내용으로 `.env.local` 파일을 수정하세요:

```bash
# Claude API (필수)
ANTHROPIC_API_KEY=sk-ant-api03-your-actual-api-key-here

# Site Configuration (필수)
NEXT_PUBLIC_SITE_URL=https://adpress.kr

# Google Services (나중에 추가, 지금은 주석 처리)
# NEXT_PUBLIC_GA_ID=
# NEXT_PUBLIC_ADSENSE_CLIENT_ID=

# Mailchimp (나중에 추가, 지금은 주석 처리)
# MAILCHIMP_API_KEY=
# MAILCHIMP_LIST_ID=

# Coupang Partners (나중에 추가, 지금은 주석 처리)
# COUPANG_ACCESS_KEY=
# COUPANG_SECRET_KEY=
```

### 중요 사항
- `ANTHROPIC_API_KEY`는 반드시 실제 API 키로 교체
- 다른 환경 변수들은 나중 단계에서 추가 예정
- `.env.local` 파일은 `.gitignore`에 포함되어 있어야 함 (보안)

### 검증

```bash
# .env.local 파일이 존재하는지 확인
ls -la .env.local

# 파일 내용 확인 (API 키는 노출되지 않도록 주의)
head -n 5 .env.local
```

---

## Step 3: 개발 서버 실행

### 실행할 명령어

```bash
# Next.js 개발 서버 시작
npm run dev
```

### 예상 결과

터미널에 다음과 같은 메시지가 표시되어야 함:

```
- Local:        http://localhost:3000
- Network:      http://192.168.x.x:3000

✓ Ready in 2.5s
```

### 브라우저 확인

1. 브라우저에서 `http://localhost:3000` 접속
2. AdPress 홈페이지가 정상적으로 로드되는지 확인

### 체크리스트
- [ ] 페이지가 로드되는가?
- [ ] 헤더(Header)가 보이는가?
- [ ] 네비게이션 메뉴가 작동하는가?
- [ ] 푸터(Footer)가 보이는가?
- [ ] CSS 스타일이 적용되어 있는가?
- [ ] 콘솔 에러가 없는가? (F12 개발자 도구 확인)

### 테스트할 페이지들

다음 URL들을 브라우저에서 확인:

```
http://localhost:3000/                  (홈페이지)
http://localhost:3000/guides            (가이드 목록)
http://localhost:3000/tips              (팁 목록)
http://localhost:3000/tools/income-calculator  (수익 계산기)
```

### 문제 해결

**페이지가 로드되지 않는 경우:**
```bash
# 캐시 삭제 후 재시작
rm -rf .next
npm run dev
```

**포트 충돌 시:**
```bash
# 다른 포트로 실행 (예: 3001)
PORT=3001 npm run dev
```

---

## Step 4: Python 환경 설정

### 실행할 명령어

```bash
# Python 버전 확인 (3.11 이상 권장)
python3 --version

# 가상환경 생성 (선택사항이지만 강력 추천)
python3 -m venv venv

# 가상환경 활성화
# Mac/Linux:
source venv/bin/activate

# Windows:
# venv\Scripts\activate

# pip 업그레이드
pip install --upgrade pip

# 프로젝트 의존성 설치
pip install -r scripts/requirements.txt
```

### 설치될 Python 패키지

- `anthropic>=0.25.0` - Claude API 클라이언트
- `python-dotenv>=1.0.0` - 환경 변수 로딩
- `pyyaml>=6.0` - YAML 파싱
- `apscheduler>=3.10.0` - 작업 스케줄링
- `requests>=2.31.0` - HTTP 요청

### 설치 확인

```bash
# 설치된 패키지 확인
pip list

# anthropic 패키지 테스트
python -c "import anthropic; print('✓ Anthropic package OK')"
```

### 예상 결과

```
✓ Anthropic package OK
```

---

## Step 5: 프로젝트 구조 검증

### 실행할 명령어

```bash
# 주요 폴더 구조 확인
tree -L 2 -I 'node_modules|.next|.git'

# 또는 ls 명령어 사용
ls -la
```

### 확인해야 할 필수 폴더/파일

```
adpress/
├── app/                  ✓ Next.js 앱 라우터
├── components/           ✓ React 컴포넌트
├── content/              ✓ MDX 콘텐츠 저장소
│   ├── guides/
│   ├── tips/
│   ├── income-reports/
│   └── reviews/
├── lib/                  ✓ 유틸리티 함수
├── scripts/              ✓ Python 자동화 스크립트
│   ├── generate_content.py
│   ├── monthly_report.py
│   └── requirements.txt
├── data/                 ✓ JSON 데이터
├── public/               ✓ 정적 파일
├── .env.local            ✓ 환경 변수 (방금 생성)
├── next.config.js        ✓ Next.js 설정
├── tailwind.config.ts    ✓ Tailwind CSS 설정
├── package.json          ✓ Node 의존성
└── tsconfig.json         ✓ TypeScript 설정
```

### 검증 스크립트 (선택사항)

다음 내용으로 `verify-setup.sh` 파일을 생성하고 실행:

```bash
#!/bin/bash

echo "🔍 AdPress 프로젝트 구조 검증..."

# 필수 폴더 확인
folders=("app" "components" "content" "lib" "scripts" "data" "public")
for folder in "${folders[@]}"; do
  if [ -d "$folder" ]; then
    echo "✓ $folder/"
  else
    echo "✗ $folder/ 누락!"
  fi
done

# 필수 파일 확인
files=(".env.local" "next.config.js" "package.json" "tailwind.config.ts")
for file in "${files[@]}"; do
  if [ -f "$file" ]; then
    echo "✓ $file"
  else
    echo "✗ $file 누락!"
  fi
done

echo ""
echo "🎉 검증 완료!"
```

실행:
```bash
chmod +x verify-setup.sh
./verify-setup.sh
```

---

## Step 6: 빌드 테스트 (선택사항)

### 실행할 명령어

```bash
# 프로덕션 빌드 생성
npm run build

# 빌드 결과 확인
ls -la out/
```

### 예상 결과

- `out/` 폴더에 정적 HTML 파일들이 생성됨
- 에러 없이 빌드 완료

### 빌드 파일 테스트

```bash
# 간단한 HTTP 서버로 빌드 결과 확인
npx serve out

# 브라우저에서 http://localhost:3000 접속하여 확인
```

---

## ✅ Phase 1 완료 체크리스트

다음 항목들이 모두 체크되면 Phase 1 완료:

- [ ] `npm install` 성공적으로 완료
- [ ] `.env.local` 파일 생성 및 `ANTHROPIC_API_KEY` 설정
- [ ] `npm run dev` 실행 시 서버 정상 작동
- [ ] 브라우저에서 홈페이지(`http://localhost:3000`) 정상 로드
- [ ] Python 가상환경 생성 및 활성화
- [ ] `pip install -r scripts/requirements.txt` 완료
- [ ] 프로젝트 폴더 구조 확인 완료
- [ ] 콘솔 에러 없음

---

## 🐛 문제 해결 가이드

### 문제 1: npm install 실패

**증상:**
```
npm ERR! code ERESOLVE
```

**해결:**
```bash
npm install --legacy-peer-deps
```

### 문제 2: Port 3000 already in use

**증상:**
```
Error: listen EADDRINUSE: address already in use :::3000
```

**해결:**
```bash
# 다른 포트 사용
PORT=3001 npm run dev

# 또는 기존 프로세스 종료
lsof -ti:3000 | xargs kill -9
```

### 문제 3: Python 패키지 설치 실패

**증상:**
```
error: externally-managed-environment
```

**해결:**
```bash
# 가상환경 사용 (권장)
python3 -m venv venv
source venv/bin/activate
pip install -r scripts/requirements.txt

# 또는 --break-system-packages 플래그 사용 (비권장)
pip install -r scripts/requirements.txt --break-system-packages
```

### 문제 4: .env.local 파일 인식 안 됨

**증상:**
API 키가 로드되지 않음

**해결:**
```bash
# 파일 이름 확인 (.env.local이 맞는지)
ls -la .env*

# 개발 서버 재시작
# Ctrl+C로 종료 후
npm run dev
```

---

## 📝 다음 단계

Phase 1 완료 후 다음 파일로 진행:

➡️ **PHASE-2-CONTENT-GENERATION.md**

- 첫 번째 콘텐츠 생성 테스트
- AI 자동화 스크립트 실행
- 콘텐츠 품질 확인

---

## 🆘 지원

문제가 발생하면:
1. 에러 메시지 전체를 복사
2. 어느 단계에서 발생했는지 명시
3. 실행한 명령어 공유

---

*Last Updated: 2024-04-14*
*Phase: 1/6*
