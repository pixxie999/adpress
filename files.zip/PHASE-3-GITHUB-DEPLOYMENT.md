# Phase 3: GitHub 저장소 및 Cloudflare Pages 배포

> 목표: 프로젝트를 GitHub에 푸시하고 Cloudflare Pages로 배포
> 예상 소요 시간: 30분

---

## 작업 개요

1. GitHub 저장소 생성
2. Git 초기화 및 코드 푸시
3. Cloudflare Pages 프로젝트 생성
4. 빌드 설정 구성
5. 배포 확인 및 테스트
6. 도메인 연결 (adpress.kr)

---

## Step 1: GitHub 저장소 생성

### 웹 브라우저에서 작업

1. GitHub 접속: https://github.com/
2. 로그인
3. 오른쪽 상단 `+` 버튼 > `New repository` 클릭

### 저장소 설정

```
Repository name: adpress-kr
Description: AdPress - 광고 수익 최적화 전문 정보 사이트
Visibility: ✓ Public (또는 Private - Cloudflare Pages는 둘 다 지원)

Initialize repository:
  [ ] Add a README file (체크 해제 - 이미 있음)
  [ ] Add .gitignore (체크 해제 - 이미 있음)
  [ ] Choose a license (선택사항)
```

4. `Create repository` 버튼 클릭

### 생성 후 확인

저장소 URL이 다음 형식이어야 함:
```
https://github.com/YOUR_USERNAME/adpress-kr
```

이 URL을 복사해두세요 (다음 단계에서 사용).

---

## Step 2: Git 초기화 및 푸시

### 로컬 프로젝트에서 Git 확인

```bash
# 프로젝트 루트 디렉토리로 이동
cd adpress

# Git이 이미 초기화되어 있는지 확인
git status

# 만약 "not a git repository" 에러가 나면:
git init
```

### .gitignore 확인

`.gitignore` 파일이 다음 내용을 포함하는지 확인:

```gitignore
# dependencies
node_modules
.pnp
.pnp.js

# testing
coverage

# next.js
.next/
out/
build
dist

# misc
.DS_Store
*.pem

# debug
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# local env files
.env
.env*.local

# python
venv/
__pycache__/
*.pyc
.pytest_cache/

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
Thumbs.db
```

### 초기 커밋 (아직 안 했다면)

```bash
# 현재 상태 확인
git status

# 모든 파일 스테이징
git add .

# 초기 커밋
git commit -m "🚀 Initial commit: AdPress.kr

- Next.js 14 프로젝트 세팅
- AI 콘텐츠 생성 시스템
- 초기 콘텐츠 6개
- Tailwind CSS 디자인 시스템"

# 커밋 확인
git log --oneline -n 1
```

### GitHub 원격 저장소 연결

```bash
# 원격 저장소 추가 (YOUR_USERNAME을 실제 GitHub 사용자명으로 교체)
git remote add origin https://github.com/YOUR_USERNAME/adpress-kr.git

# 원격 저장소 확인
git remote -v

# 예상 출력:
# origin  https://github.com/YOUR_USERNAME/adpress-kr.git (fetch)
# origin  https://github.com/YOUR_USERNAME/adpress-kr.git (push)
```

### 메인 브랜치 설정 및 푸시

```bash
# 브랜치 이름을 main으로 변경 (기본이 master인 경우)
git branch -M main

# GitHub에 푸시
git push -u origin main
```

### 푸시 인증

**방법 1: Personal Access Token (권장)**

1. GitHub Settings > Developer settings > Personal access tokens > Tokens (classic)
2. Generate new token (classic)
3. Scopes 선택: `repo` 체크
4. Generate token
5. 토큰 복사 (한 번만 보임!)
6. 푸시 시 비밀번호 대신 토큰 입력

**방법 2: SSH Key**

이미 설정되어 있다면 바로 푸시됨.

### 푸시 확인

```bash
# 푸시 성공 메시지 확인
# Enumerating objects: 100, done.
# ...
# To https://github.com/YOUR_USERNAME/adpress-kr.git
#  * [new branch]      main -> main

# 브라우저에서 GitHub 저장소 확인
# https://github.com/YOUR_USERNAME/adpress-kr
```

---

## Step 3: Cloudflare Pages 프로젝트 생성

### Cloudflare 대시보드 접속

1. 브라우저에서 https://dash.cloudflare.com/ 접속
2. 로그인 (계정 없으면 무료 가입)

### Pages 프로젝트 생성

```
1. 좌측 메뉴에서 "Workers & Pages" 클릭
2. "Create application" 버튼 클릭
3. "Pages" 탭 선택
4. "Connect to Git" 클릭
```

### GitHub 연결

```
5. "GitHub" 선택
6. "Connect GitHub" 버튼 클릭
7. GitHub 인증 팝업에서 "Authorize Cloudflare Pages" 클릭
8. 저장소 선택 화면에서:
   - "All repositories" 또는
   - "Only select repositories" > "adpress-kr" 선택
9. "Install & Authorize" 클릭
```

### 저장소 선택

```
10. Cloudflare Pages로 돌아와서
11. "adpress-kr" 저장소 선택
12. "Begin setup" 클릭
```

---

## Step 4: 빌드 설정 구성

### 프로젝트 설정

```
Project name: adpress-kr
Production branch: main
```

### Build settings

**중요: 다음 설정을 정확히 입력하세요**

```
Framework preset: Next.js

Build command:
npm run build

Build output directory:
out

Root directory:
/
(비워두거나 슬래시만 입력)
```

### Environment variables (환경 변수)

**필수 환경 변수 추가:**

`Add variable` 버튼을 클릭하여 다음 변수들을 추가:

```
Variable name: ANTHROPIC_API_KEY
Value: sk-ant-api03-your-actual-api-key-here
```

```
Variable name: NEXT_PUBLIC_SITE_URL
Value: https://adpress.kr
```

```
Variable name: NODE_VERSION
Value: 18
```

**선택적 환경 변수 (나중에 추가 가능):**

```
NEXT_PUBLIC_GA_ID=
NEXT_PUBLIC_ADSENSE_CLIENT_ID=
MAILCHIMP_API_KEY=
MAILCHIMP_LIST_ID=
```

### 저장 및 배포

```
13. "Save and Deploy" 버튼 클릭
```

---

## Step 5: 배포 확인

### 빌드 프로세스 모니터링

배포가 시작되면 다음과 같은 단계를 볼 수 있음:

```
1. Initializing build environment
2. Cloning repository
3. Installing dependencies (npm install)
4. Building application (npm run build)
5. Deploying to Cloudflare network
```

### 예상 빌드 시간

- 첫 배포: 3-5분
- 이후 배포: 1-3분 (캐시 활용)

### 빌드 로그 확인

터미널처럼 생긴 화면에서 실시간 로그 확인:

```
✓ Cloning repository
✓ Installing dependencies
  npm install
  added 1234 packages in 45s
✓ Building application
  npm run build
  > next build
  ✓ Creating an optimized production build
  ✓ Compiled successfully
✓ Deploying to Cloudflare Pages
  ✓ Success! Deployed to https://adpress-kr.pages.dev
```

### 배포 성공 확인

**초기 URL 테스트:**

```
https://[random-subdomain].adpress-kr.pages.dev
```

브라우저에서 이 URL에 접속하여 사이트가 정상 작동하는지 확인:

- [ ] 홈페이지 로드
- [ ] 가이드 목록 페이지 (/guides)
- [ ] 개별 가이드 페이지
- [ ] CSS 스타일 적용
- [ ] 이미지 로드

---

## Step 6: 도메인 연결 (adpress.kr)

### Cloudflare에서 도메인 설정

#### Option A: 도메인이 이미 Cloudflare에 있는 경우

```
1. Cloudflare Pages 프로젝트 페이지에서
2. "Custom domains" 탭 클릭
3. "Set up a custom domain" 버튼 클릭
4. 도메인 입력: adpress.kr
5. "Continue" 클릭
6. Cloudflare가 자동으로 DNS 레코드 생성
7. "Activate domain" 클릭
```

#### Option B: 도메인이 다른 곳에 있는 경우

**먼저 Cloudflare로 네임서버 변경:**

```
1. Cloudflare 대시보드에서 "Add a site" 클릭
2. adpress.kr 입력
3. Free plan 선택
4. Cloudflare 네임서버 확인:
   - name1.cloudflare.com
   - name2.cloudflare.com

5. 도메인 등록업체(가비아, 후이즈 등)에서:
   - 도메인 관리 > 네임서버 설정
   - Cloudflare 네임서버로 변경
   - 저장 (전파 시간: 최대 24시간, 보통 1-2시간)

6. Cloudflare로 돌아와서:
   - DNS 전파 확인 대기
   - "Continue" 클릭
```

**그 다음 Custom Domain 추가:**

위 Option A와 동일하게 진행.

### DNS 레코드 확인

Cloudflare DNS 관리 페이지에서 다음 레코드가 생성되었는지 확인:

```
Type: CNAME
Name: @
Target: adpress-kr.pages.dev
Proxy status: Proxied (주황색 구름 아이콘)
```

또는

```
Type: CNAME
Name: adpress.kr
Target: adpress-kr.pages.dev
Proxy status: Proxied
```

### SSL/TLS 설정

```
1. Cloudflare 대시보드 > SSL/TLS
2. Encryption mode: "Full (strict)" 선택
3. Edge Certificates:
   - "Always Use HTTPS" ON
   - "Automatic HTTPS Rewrites" ON
```

### 도메인 접속 테스트

**기다린 후 (DNS 전파 시간: 5분~2시간):**

```
https://adpress.kr
```

브라우저에서 접속하여 확인:

- [ ] HTTPS 자물쇠 아이콘 표시
- [ ] 홈페이지 정상 로드
- [ ] SSL 인증서 유효 (자물쇠 클릭하여 확인)

---

## Step 7: 배포 자동화 확인

### GitHub에서 코드 수정 시 자동 배포 테스트

```bash
# 로컬에서 간단한 수정
echo "# AdPress.kr" > TEST.md

# Git 추가 및 커밋
git add TEST.md
git commit -m "test: 자동 배포 테스트"

# GitHub에 푸시
git push origin main
```

### Cloudflare Pages에서 확인

```
1. Cloudflare Pages 프로젝트 페이지
2. "Deployments" 탭
3. 새로운 배포가 자동으로 시작되는지 확인
4. 빌드 완료 후 https://adpress.kr 에서 변경사항 반영 확인
```

---

## ✅ Phase 3 완료 체크리스트

다음 항목들이 모두 체크되면 Phase 3 완료:

- [ ] GitHub 저장소 생성 완료
- [ ] 로컬 코드를 GitHub에 푸시
- [ ] Cloudflare Pages 프로젝트 생성
- [ ] 빌드 설정 완료 (Next.js, npm run build, out)
- [ ] 환경 변수 설정 (ANTHROPIC_API_KEY, NEXT_PUBLIC_SITE_URL)
- [ ] 첫 배포 성공
- [ ] .pages.dev 도메인 접속 확인
- [ ] 커스텀 도메인 (adpress.kr) 연결
- [ ] SSL 인증서 활성화
- [ ] https://adpress.kr 접속 성공
- [ ] 자동 배포 테스트 완료

---

## 🔍 배포 후 확인사항

### 성능 체크

**PageSpeed Insights 테스트:**

```
https://pagespeed.web.dev/

URL 입력: https://adpress.kr
```

**목표 지표:**
- Performance: 90+ (Mobile), 95+ (Desktop)
- Accessibility: 95+
- Best Practices: 95+
- SEO: 95+

### 기능 테스트 체크리스트

```
[ ] 홈페이지 (/)
[ ] 가이드 목록 (/guides)
[ ] 가이드 상세 (/guides/[slug])
[ ] 팁 목록 (/tips)
[ ] 팁 상세 (/tips/[slug])
[ ] 수익 계산기 (/tools/income-calculator)
[ ] 404 페이지
[ ] Sitemap (/sitemap.xml)
[ ] Robots.txt (/robots.txt)
```

### SEO 메타태그 확인

브라우저에서 F12 > Elements > `<head>` 확인:

```html
<title>페이지 제목 | AdPress</title>
<meta name="description" content="...">
<meta property="og:title" content="...">
<meta property="og:image" content="...">
<link rel="canonical" href="https://adpress.kr/...">
```

---

## 🐛 문제 해결 가이드

### 문제 1: 빌드 실패 (Build failed)

**증상:**
```
Error: Command failed with exit code 1
```

**해결:**

1. **로컬에서 빌드 테스트:**
```bash
npm run build
```

2. **에러 확인 후 수정**

3. **수정 사항 푸시:**
```bash
git add .
git commit -m "fix: 빌드 에러 수정"
git push origin main
```

### 문제 2: 환경 변수 누락

**증상:**
사이트는 로드되지만 일부 기능 작동 안 함

**해결:**

```
1. Cloudflare Pages > 프로젝트 선택
2. Settings > Environment variables
3. 누락된 변수 추가
4. Deployments > 최근 배포 > "Retry deployment"
```

### 문제 3: 도메인 접속 안 됨

**증상:**
```
DNS_PROBE_FINISHED_NXDOMAIN
```

**해결:**

```bash
# DNS 전파 확인
nslookup adpress.kr

# 또는
dig adpress.kr

# Cloudflare DNS 레코드 재확인
```

**대기 시간:**
- DNS 변경 후 최대 24시간 (보통 1-2시간)
- Cloudflare 프록시 사용 시 더 빠름 (5-10분)

### 문제 4: SSL 인증서 에러

**증상:**
```
Your connection is not private
NET::ERR_CERT_COMMON_NAME_INVALID
```

**해결:**

```
1. Cloudflare > SSL/TLS
2. Edge Certificates
3. "Universal SSL" 활성화 확인
4. 대기 (최대 15분)
```

---

## 📊 배포 상태 모니터링

### Cloudflare Analytics

```
Cloudflare Pages > 프로젝트 > Analytics

확인 가능한 지표:
- Requests (요청 수)
- Bandwidth (대역폭)
- Unique visitors (순방문자)
- Performance metrics
```

### Deployment 히스토리

```
Cloudflare Pages > 프로젝트 > Deployments

각 배포별:
- 배포 시간
- Git 커밋 정보
- 빌드 로그
- Preview URL
```

---

## 🎯 다음 단계 미리보기

Phase 3 완료 후:

➡️ **PHASE-4-SEO-SETUP.md**

- Google Search Console 등록
- Naver Search Advisor 등록
- Google Analytics 4 설정
- Sitemap 제출

---

## 💡 추가 팁

### Cloudflare 무료 플랜 제한

```
✓ 무제한 대역폭
✓ 무제한 요청
✓ 500 빌드/월
✓ Concurrent builds: 1
✓ 커스텀 도메인 무제한
```

### Git Workflow

앞으로 콘텐츠 추가 시:

```bash
# 1. 콘텐츠 생성
python scripts/generate_content.py --keyword "..." --category guides

# 2. 로컬에서 확인
npm run dev

# 3. Git 커밋
git add content/
git commit -m "content: 새 가이드 추가 - [제목]"

# 4. 푸시 (자동 배포)
git push origin main

# 5. Cloudflare에서 배포 확인
# 6. 2-3분 후 https://adpress.kr 에서 확인
```

### Branch 전략 (선택사항)

프로덕션 안정성을 위해:

```bash
# develop 브랜치 생성
git checkout -b develop

# 작업
git add .
git commit -m "..."

# GitHub에 푸시
git push origin develop

# Cloudflare Pages에서 develop 브랜치도 자동 배포
# Preview URL로 확인 후
# 문제 없으면 main으로 병합
```

---

*Last Updated: 2024-04-14*
*Phase: 3/6*
